#include<stdio.h>
int main(){
	for(int a = 0 ;a<3;a++){
		for(int b = 0;b<5;b++ ){
			printf("*");
			
		}
		printf("\n");
	}
	return 0;
}
